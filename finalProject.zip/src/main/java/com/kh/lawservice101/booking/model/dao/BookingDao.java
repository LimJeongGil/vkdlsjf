package com.kh.lawservice101.booking.model.dao;

import com.kh.lawservice101.booking.model.vo.BookingVo;
import com.kh.lawservice101.payment.model.vo.PaymentVo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface BookingDao {

    void insertBooking(BookingVo bookingVo);

    BookingVo selectLatestBooking(Long clientNum);

    BookingVo selectLatestCounseling(Long lawyerNum);

    BookingVo selectBookingDetail(Long bookingNum);

    List<BookingVo> selectBookingByDate(String selectDate);
}
