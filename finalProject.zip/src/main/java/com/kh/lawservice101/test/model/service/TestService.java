package com.kh.lawservice101.test.model.service;

public interface TestService {
    void join(String id, String password);
}
