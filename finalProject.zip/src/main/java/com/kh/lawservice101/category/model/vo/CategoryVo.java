package com.kh.lawservice101.category.model.vo;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CategoryVo {
    private Long categoryNum;
    private String categoryName;
}
