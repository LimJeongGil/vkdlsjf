$(function () {
    $(".searchForm").hide();
});