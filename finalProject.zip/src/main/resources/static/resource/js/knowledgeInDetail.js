function validate(replyContent) {
    return true;
}